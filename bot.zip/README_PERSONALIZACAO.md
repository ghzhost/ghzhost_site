# 🤖 Guia de Personalização da IA GHZhost

## 📋 Resumo do Sistema

O sistema de IA está **100% funcional** e pronto para uso! Aqui está um resumo do que foi implementado:

### ✅ **O que já está configurado:**

1. **Chat Interface Responsivo**
   - Sidebar moderna com dark mode
   - Compatible com o design GHZhost
   - Animações suaves e indicadores de digitação

2. **IA Personalizada "Luna"**
   - Personalidade amigável e entusiasmada
   - Tom brasileiro informal
   - Uso de emojis e linguagem acolhedora

3. **Planos Atualizados (2025)**
   - **Velocity**: R$ 29,90/mês - 20 GB SSD NVMe
   - **Quantum**: R$ 49,90/mês - 50 GB SSD NVMe  
   - **Supernova**: R$ 99,90/mês - 100 GB SSD NVMe

4. **Sistema de Intenções Inteligente**
   - Reconhece perguntas sobre planos, preços, suporte
   - Respostas contextuais baseadas na conversa
   - Sugestões automáticas de próximas perguntas

---

## 🎨 Como Personalizar Ainda Mais

### 1. **Mudando a Personalidade da IA**

No arquivo `systemInstruction.js`, modifique a seção `personality`:

```javascript
personality: {
    name: "Maria",                    // Mude o nome
    tone: "profissional e técnica",   // Ou: "casual", "formal", "amigável"
    emoji_usage: false,               // true/false para emojis
    language_style: "formal",         // "formal", "informal", "técnico"
    response_length: "curto",         // "curto", "médio", "longo"
    characteristics: [
        "especialista em tecnologia",
        "focada em soluções",
        "direta e objetiva"
    ]
}
```

### 2. **Atualizando Preços e Planos**

```javascript
plans: {
    "starter": { 
        name: "Starter",
        price: "R$ 19,90", 
        storage: "10 GB SSD", 
        features: ["cPanel", "SSL Grátis"],
        description: "Ideal para iniciantes"
    },
    // Adicione ou remova planos conforme necessário
}
```

### 3. **Personalizando Respostas**

Modifique as respostas em `initializeResponses()`:

```javascript
greeting: [
    "Olá! Sou o assistente da [SUA_EMPRESA]. Como posso ajudar?",
    "Bem-vindo! Em que posso auxiliá-lo hoje?"
],
```

### 4. **Adicionando Novas Palavras-chave**

Em `analyzeIntent()`, adicione novos tipos de intenção:

```javascript
const intents = {
    // Adicione nova categoria
    backup: ["backup", "copia", "seguranca", "restaurar"],
    // ...existing intents
};
```

---

## 🔧 Configurações Avançadas

### **Horário de Atendimento Personalizado**
```javascript
supportHours: "Segunda a Sexta: 8h às 18h, Sábados: 8h às 12h",
```

### **Informações de Contato**
Atualize na seção `contact` das respostas:
```javascript
contact: [
    "📞 Entre em contato:\n🌐 www.suaempresa.com\n📧 suporte@suaempresa.com\n📱 (11) 1234-5678"
]
```

### **Respostas Condicionais Inteligentes**
Adicione lógica especial em `selectResponse()`:

```javascript
if (intent === "plans" && userMessage.includes("e-commerce")) {
    return "Para e-commerce recomendo o plano Premium com 4GB RAM e SSL dedicado!";
}
```

---

## 🎯 Exemplos de Uso Específico

### **Para Empresa de Desenvolvimento Web:**
```javascript
services: [
    "desenvolvimento web", 
    "apps mobile", 
    "consultoria técnica", 
    "hospedagem especializada"
],

personality: {
    name: "CodeBot",
    tone: "técnico e especializado",
    characteristics: ["expert em código", "focado em performance"]
}
```

### **Para Empresa de Marketing Digital:**
```javascript
services: [
    "campanhas Google Ads", 
    "gestão de redes sociais", 
    "criação de sites", 
    "consultoria em SEO"
],

personality: {
    name: "MarketBot",
    tone: "criativo e estratégico", 
    characteristics: ["especialista em conversões", "focado em resultados"]
}
```

---

## 📊 Recursos Disponíveis

### **Funções Públicas:**
- `processAIMessage(mensagem)` - Processa mensagem do usuário
- `getAIWelcomeMessage()` - Mensagem de boas-vindas
- `clearAIHistory()` - Limpa histórico da conversa
- `getAIStats()` - Estatísticas da conversa

### **Exemplo de Integração:**
```javascript
// Processa uma mensagem
const resposta = processAIMessage("Qual o melhor plano?");
console.log(resposta.message);
console.log(resposta.suggestions);

// Obtém estatísticas
const stats = getAIStats();
console.log(`Total de mensagens: ${stats.totalMessages}`);
```

---

## 🚀 Próximos Passos Sugeridos

1. **Teste o Sistema**
   - Abra `IAbarra.html` no navegador
   - Converse com a Luna e teste diferentes perguntas

2. **Personalize Gradualmente**
   - Comece mudando o nome e tom da IA
   - Atualize os preços dos seus planos reais
   - Adicione suas informações de contato

3. **Monitore e Ajuste**
   - Veja quais perguntas os clientes fazem mais
   - Adicione novas palavras-chave conforme necessário
   - Refine as respostas baseado no feedback

4. **Integração no Site**
   - Copie o código do chat para suas páginas
   - Ajuste as cores para combinar com sua marca
   - Teste em diferentes dispositivos

---

## 💡 Dicas Importantes

- **Backup**: Sempre faça backup antes de modificar
- **Teste**: Teste cada mudança antes de colocar em produção
- **Consistência**: Mantenha o tom da IA consistente em todas as respostas
- **Atualização**: Revise e atualize regularmente conforme sua empresa evolui

---

**🎉 Seu sistema de IA está pronto para revolucionar o atendimento ao cliente!**

Para dúvidas ou suporte adicional, consulte os comentários detalhados no código `systemInstruction.js`.
