/**
 * Rotas da API GHZhost IA
 * Versão: 4.0
 */

const express = require('express');
const router = express.Router();

// Middleware para validação de entrada
const validateMessage = (req, res, next) => {
    const { message } = req.body;
    
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
        return res.status(400).json({
            error: 'Mensagem inválida',
            message: 'O campo "message" é obrigatório e deve ser uma string não vazia'
        });
    }
    
    if (message.length > 1000) {
        return res.status(400).json({
            error: 'Mensagem muito longa',
            message: 'A mensagem deve ter no máximo 1000 caracteres'
        });
    }
    
    next();
};

// POST /api/chat - Endpoint principal para conversa
router.post('/chat', validateMessage, async (req, res) => {
    try {
        const { message, sessionId } = req.body;
        const session = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        console.log(`💬 Nova mensagem [${session}]: ${message}`);
        
        const response = await req.ai.processMessage(message, session);
        
        res.json({
            success: true,
            data: {
                message: response.message,
                intent: response.intent,
                suggestions: response.suggestions,
                source: response.source,
                sessionId: session,
                timestamp: new Date().toISOString()
            }
        });
        
    } catch (error) {
        console.error('Erro no endpoint chat:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor',
            message: 'Não foi possível processar a mensagem'
        });
    }
});

// GET /api/welcome - Mensagem de boas-vindas
router.get('/welcome', (req, res) => {
    try {
        const welcomeMessage = req.ai.getWelcomeMessage();
        
        res.json({
            success: true,
            data: {
                message: welcomeMessage,
                intent: 'greeting',
                suggestions: req.ai.getSuggestions('greeting'),
                source: 'welcome',
                timestamp: new Date().toISOString()
            }
        });
        
    } catch (error) {
        console.error('Erro no endpoint welcome:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor'
        });
    }
});

// GET /api/stats/:sessionId - Estatísticas da conversa
router.get('/stats/:sessionId?', (req, res) => {
    try {
        const sessionId = req.params.sessionId || 'default';
        const stats = req.ai.getConversationStats(sessionId);
        
        res.json({
            success: true,
            data: stats
        });
        
    } catch (error) {
        console.error('Erro no endpoint stats:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor'
        });
    }
});

// DELETE /api/history/:sessionId - Limpar histórico
router.delete('/history/:sessionId?', (req, res) => {
    try {
        const sessionId = req.params.sessionId || 'default';
        req.ai.clearHistory(sessionId);
        
        res.json({
            success: true,
            message: sessionId === 'all' ? 'Todos os históricos foram limpos' : `Histórico da sessão ${sessionId} foi limpo`,
            sessionId: sessionId
        });
        
    } catch (error) {
        console.error('Erro no endpoint history:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor'
        });
    }
});

// GET /api/test - Teste de conectividade
router.get('/test', async (req, res) => {
    try {
        const testResult = await req.ai.testConnection();
        
        res.json({
            success: true,
            data: testResult
        });
        
    } catch (error) {
        console.error('Erro no endpoint test:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor',
            message: 'Não foi possível testar a conexão'
        });
    }
});

// GET /api/info - Informações da API
router.get('/info', (req, res) => {
    try {
        res.json({
            success: true,
            data: {
                name: 'GHZhost IA API',
                version: '4.0',
                description: 'API para chatbot da GHZhost usando Google Gemini',
                endpoints: {
                    'POST /api/chat': 'Enviar mensagem para a IA',
                    'GET /api/welcome': 'Obter mensagem de boas-vindas',
                    'GET /api/stats/:sessionId': 'Obter estatísticas da conversa',
                    'DELETE /api/history/:sessionId': 'Limpar histórico da sessão',
                    'GET /api/test': 'Testar conectividade com Gemini',
                    'GET /api/info': 'Informações da API'
                },
                company: {
                    name: 'GHZhost',
                    services: ['hospedagem web', 'servidores VPS', 'registro de domínios', 'SSL', 'email profissional', 'backup'],
                    support: '24/7'
                },
                ai: {
                    name: 'Luna',
                    role: 'Consultora de Serviços',
                    powered_by: 'Google Gemini'
                }
            }
        });
        
    } catch (error) {
        console.error('Erro no endpoint info:', error);
        res.status(500).json({
            success: false,
            error: 'Erro interno do servidor'
        });
    }
});

module.exports = router;
