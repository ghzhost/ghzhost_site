/**
 * Serviço GHZhost IA com Google Gemini
 * Versão: 4.0 - Refatorado para Node.js
 * Data: Julho 2025
 */

class GHZhostAI {
    constructor() {
        // Configurações da API Gemini
        this.geminiApiKey = process.env.GEMINI_API_KEY;
        this.geminiApiUrl = process.env.GEMINI_API_URL;
        
        // Configurações da empresa
        this.context = {
            company: process.env.COMPANY_NAME || "GHZhost",
            
            services: [
                "hospedagem web", 
                "servidores VPS", 
                "registro de domínios", 
                "SSL", 
                "email profissional", 
                "backup"
            ],
            
            plans: {
                "velocity": { 
                    name: "Velocity",
                    price: "R$ 29,90", 
                    storage: "20 GB SSD NVMe", 
                    features: "LiteSpeed, HestiaCP, Suporte 24/7",
                    description: "Ideal para sites pessoais e pequenos projetos"
                },
                "quantum": { 
                    name: "Quantum",
                    price: "R$ 49,90", 
                    storage: "50 GB SSD NVMe", 
                    features: "cPanel®, 2 vCPU / 2 GB RAM, Domínio Grátis",
                    description: "Perfeito para sites empresariais e e-commerce"
                },
                "supernova": { 
                    name: "Supernova",
                    price: "R$ 99,90", 
                    storage: "100 GB SSD NVMe", 
                    features: "cPanel® & WHM, 4 vCPU / 4 GB RAM, Acesso SSH & Git",
                    description: "Para desenvolvedores e projetos avançados"
                }
            },
            
            supportHours: process.env.SUPPORT_HOURS || "24/7",
            
            personality: {
                name: "Luna",
                role: "Consultora de Serviços GHZhost",
                tone: "amigável e consultiva",
                emoji_usage: true,
                language_style: "brasileiro informal",
                response_length: "médio",
                characteristics: [
                    "especialista em todos os serviços GHZhost",
                    "esclarece dúvidas sobre preços e benefícios", 
                    "orienta na escolha da melhor solução",
                    "sempre prestativa e informativa",
                    "focada em apresentar os diferenciais da empresa"
                ]
            }
        };
        
        this.conversationHistory = new Map(); // Usar Map para múltiplas sessões
        this.systemPrompt = this.buildSystemPrompt();
        this.fallbackResponses = this.initializeFallbackResponses();
        
        // Validação da API Key
        if (!this.geminiApiKey) {
            console.warn('⚠️  GEMINI_API_KEY não configurada! Usando apenas fallback responses.');
        }
    }

    // Constrói o prompt do sistema
    buildSystemPrompt() {
        return `Você é Luna, consultora de serviços da GHZhost, uma empresa brasileira de hospedagem web. 

PERSONALIDADE:
- Nome: Luna
- Função: Consultora de Serviços GHZhost
- Tom: Amigável, consultiva e prestativa
- Estilo: Brasileiro informal com emojis
- Características: Especialista em todos os serviços, esclarece dúvidas sobre preços e benefícios, orienta na escolha da melhor solução

INFORMAÇÕES DA EMPRESA:
- Nome: GHZhost
- Serviços: Hospedagem web, servidores VPS, registro de domínios, SSL, email profissional, backup
- Suporte: 24/7 - 24 horas por dia, 7 dias por semana

PLANOS DE HOSPEDAGEM:
1. **Velocity** - R$ 29,90/mês
   - 20 GB SSD NVMe
   - LiteSpeed, HestiaCP, Suporte 24/7
   - Ideal para sites pessoais e pequenos projetos

2. **Quantum** - R$ 49,90/mês
   - 50 GB SSD NVMe
   - cPanel®, 2 vCPU / 2 GB RAM, Domínio Grátis
   - Perfeito para sites empresariais e e-commerce

3. **Supernova** - R$ 99,90/mês
   - 100 GB SSD NVMe
   - cPanel® & WHM, 4 vCPU / 4 GB RAM, Acesso SSH & Git
   - Para desenvolvedores e projetos avançados

DIFERENCIAIS:
- Migração 100% gratuita
- SSL grátis em todos os planos
- Tecnologia SSD NVMe
- Backup automático diário
- 99.9% de uptime garantido
- Suporte especializado em português

INSTRUÇÕES DE RESPOSTA:
- Sempre responda como Luna da GHZhost
- Use emojis apropriados
- Seja consultiva e ajude na escolha do melhor plano
- Destaque os benefícios e diferenciais da empresa
- Mantenha tom amigável e brasileiro
- Forneça informações precisas sobre preços e benefícios
- Sugira o plano mais adequado baseado nas necessidades do cliente
- Respostas devem ser informativas mas não muito longas (2-4 parágrafos)`;
    }

    // Inicializa respostas de fallback
    initializeFallbackResponses() {
        return {
            greeting: [
                "Oi! 👋 Eu sou a Luna, consultora de serviços da GHZhost! Estou aqui pra te ajudar a conhecer nossos serviços e esclarecer qualquer dúvida sobre preços e benefícios! Como posso te ajudar? 😊",
                "Olá! 🌟 Sou a Luna da GHZhost! Posso te apresentar nossos serviços, explicar preços e benefícios, e te ajudar a encontrar a solução perfeita! O que gostaria de saber?",
                "E aí! 🚀 Luna aqui, sua consultora GHZhost! Estou pronta pra te mostrar tudo sobre nossos serviços, esclarecer dúvidas e te ajudar a escolher o melhor plano! Em que posso ajudar?"
            ],
            
            plans: [
                `🌟 Olha só nossos planos incríveis:\n\n🚀 **Velocity** - ${this.context.plans.velocity.price}/mês\n   ${this.context.plans.velocity.storage} | ${this.context.plans.velocity.features}\n\n⚡ **Quantum** - ${this.context.plans.quantum.price}/mês\n   ${this.context.plans.quantum.storage} | ${this.context.plans.quantum.features}\n\n🔥 **Supernova** - ${this.context.plans.supernova.price}/mês\n   ${this.context.plans.supernova.storage} | ${this.context.plans.supernova.features}\n\nTodos com tecnologia de ponta! Qual combina mais com seu projeto? 🤔`,
                "🎯 Temos 3 planos que são uma maravilha! O **Velocity** (R$ 29,90) é perfeito pra começar, o **Quantum** (R$ 49,90) é o queridinho da galera, e o **Supernova** (R$ 99,90) é pra quem quer performance máxima! Qual te chamou atenção? ✨"
            ],
            
            error: [
                "😅 Eita! Deu um bug aqui... Mas relaxa que vou te conectar com um humano especialista rapidinho! 🔧",
                "🤖 Ops, meus circuitos deram uma travada... Nossa equipe de suporte vai entrar em contato! Prometo que vai dar tudo certo! ✨",
                "🔄 Houve um probleminha técnico, mas já estou trabalhando pra resolver! Você pode reformular sua pergunta ou aguardar um momento? 💫"
            ],
            
            default: [
                "🤔 Hmm, não consegui entender direito... Pode reformular pra mim? Prometo que vou captar na próxima! 😅",
                "💭 Posso te ajudar com hospedagem, domínios, preços, suporte... O que você gostaria de saber? Me dá uma dica! 🎯",
                "❓ Opa, não peguei essa! Pode dar mais detalhes do que você precisa? Assim consigo te ajudar melhor! 💡"
            ]
        };
    }

    // Chama a API do Google Gemini
    async callGeminiAPI(userMessage, sessionId = 'default') {
        if (!this.geminiApiKey) {
            throw new Error('API Key do Gemini não configurada');
        }

        try {
            const fetch = (await import('node-fetch')).default;
            
            // Prepara o histórico da conversa
            let conversationContext = "";
            const sessionHistory = this.conversationHistory.get(sessionId) || [];
            
            if (sessionHistory.length > 0) {
                const recentHistory = sessionHistory.slice(-6);
                conversationContext = "\n\nCONTEXTO DA CONVERSA:\n";
                recentHistory.forEach((msg) => {
                    conversationContext += `${msg.type === 'user' ? 'Cliente' : 'Luna'}: ${msg.message}\n`;
                });
            }

            const requestBody = {
                contents: [{
                    parts: [{
                        text: `${this.systemPrompt}${conversationContext}\n\nNOVA MENSAGEM DO CLIENTE: ${userMessage}\n\nRESPONDA COMO LUNA:`
                    }]
                }],
                generationConfig: {
                    temperature: 0.7,
                    maxOutputTokens: 500,
                    topK: 40,
                    topP: 0.8
                }
            };

            const response = await fetch(`${this.geminiApiUrl}?key=${this.geminiApiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status} - ${response.statusText}`);
            }

            const data = await response.json();
            
            if (data.candidates && data.candidates[0] && data.candidates[0].content) {
                return data.candidates[0].content.parts[0].text;
            } else {
                throw new Error('Formato de resposta inválido da API Gemini');
            }

        } catch (error) {
            console.error('Erro na chamada da API Gemini:', error);
            throw error;
        }
    }

    // Analisa a intenção do usuário
    analyzeIntent(message) {
        const msg = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
        
        const intents = {
            greeting: ["ola", "oi", "bom dia", "boa tarde", "boa noite", "hey", "hello"],
            services: ["servicos", "servico", "ofertas", "oferta", "produtos", "produto", "solucoes", "solucao"],
            plans: ["plano", "planos", "hospedagem", "hosting", "pacote", "pacotes"],
            pricing: ["preco", "precos", "valor", "valores", "custo", "custos", "quanto", "barato"],
            benefits: ["beneficios", "beneficio", "vantagens", "vantagem", "diferenciais", "diferencial"],
            support: ["suporte", "ajuda", "problema", "erro", "duvida", "atendimento"],
            domains: ["dominio", "dominios", "site", "registro", "url", "endereco"],
            ssl: ["ssl", "certificado", "seguranca", "https", "criptografia"],
            technical: ["tecnico", "especificacao", "php", "mysql", "cpanel", "servidor"],
            migration: ["migracao", "migrar", "transferir", "mudar", "trocar"],
            contact: ["contato", "telefone", "email", "endereco", "localizacao"],
            thanks: ["obrigado", "obrigada", "valeu", "grato", "grata", "agradeco"]
        };

        for (const [intent, keywords] of Object.entries(intents)) {
            if (keywords.some(keyword => msg.includes(keyword))) {
                return intent;
            }
        }

        return "default";
    }

    // Processa a mensagem
    async processMessage(userMessage, sessionId = 'default') {
        try {
            // Inicializa histórico da sessão se não existir
            if (!this.conversationHistory.has(sessionId)) {
                this.conversationHistory.set(sessionId, []);
            }
            
            const sessionHistory = this.conversationHistory.get(sessionId);
            
            // Adiciona mensagem do usuário ao histórico
            sessionHistory.push({
                type: "user",
                message: userMessage,
                timestamp: new Date()
            });

            // Analisa intenção
            const intent = this.analyzeIntent(userMessage);

            // Chama API do Gemini
            const geminiResponse = await this.callGeminiAPI(userMessage, sessionId);

            // Adiciona resposta ao histórico
            sessionHistory.push({
                type: "bot",
                message: geminiResponse,
                timestamp: new Date(),
                intent: intent
            });

            return {
                success: true,
                message: geminiResponse,
                intent: intent,
                suggestions: this.getSuggestions(intent),
                source: "gemini",
                sessionId: sessionId
            };

        } catch (error) {
            console.error("Erro no processamento da IA:", error);
            
            // Fallback para resposta local
            const intent = this.analyzeIntent(userMessage);
            const fallbackResponse = this.getFallbackResponse(intent);
            
            // Adiciona resposta de fallback ao histórico
            const sessionHistory = this.conversationHistory.get(sessionId) || [];
            sessionHistory.push({
                type: "bot",
                message: fallbackResponse,
                timestamp: new Date(),
                intent: intent
            });

            return {
                success: false,
                message: fallbackResponse,
                intent: intent,
                suggestions: this.getSuggestions(intent),
                source: "fallback",
                error: error.message,
                sessionId: sessionId
            };
        }
    }

    // Retorna resposta de fallback
    getFallbackResponse(intent) {
        const responses = this.fallbackResponses[intent] || this.fallbackResponses.default;
        return responses[Math.floor(Math.random() * responses.length)];
    }

    // Retorna sugestões baseadas na intenção
    getSuggestions(currentIntent) {
        const suggestions = {
            greeting: ["Ver nossos serviços", "Conhecer os planos", "Preços e benefícios"],
            services: ["Qual plano é melhor pra mim?", "Quais os preços?", "Benefícios da GHZhost"],
            plans: ["Qual plano é melhor pra mim?", "Posso migrar meu site grátis?", "Quais os benefícios?"],
            pricing: ["Ver todos os planos", "Quais os benefícios?", "Como funciona a migração?"],
            benefits: ["Ver planos detalhados", "Como funciona o suporte?", "Preços dos domínios"],
            support: ["Horários de atendimento", "Como migrar meu site", "Formas de contato"],
            domains: ["Registrar domínio", "Preços de domínios", "Incluído nos planos?"],
            ssl: ["SSL grátis nos planos?", "Como funciona o SSL?", "Certificados disponíveis"],
            technical: ["Especificações técnicas", "Tecnologias suportadas", "Painel de controle"],
            migration: ["Migração gratuita", "Como funciona?", "Quanto tempo demora?"],
            contact: ["Telefone de contato", "Email suporte", "Outros canais"],
            thanks: ["Conhecer outros serviços", "Falar com especialista", "Assinar plano"],
            default: ["Ver nossos serviços", "Conhecer os planos", "Suporte 24h", "Registrar domínio"]
        };

        return suggestions[currentIntent] || suggestions.default;
    }

    // Retorna estatísticas da conversa
    getConversationStats(sessionId = 'default') {
        const sessionHistory = this.conversationHistory.get(sessionId) || [];
        
        return {
            sessionId: sessionId,
            totalMessages: sessionHistory.length,
            userMessages: sessionHistory.filter(m => m.type === "user").length,
            botMessages: sessionHistory.filter(m => m.type === "bot").length,
            intents: [...new Set(sessionHistory.filter(m => m.intent).map(m => m.intent))],
            duration: sessionHistory.length > 0 ? 
                new Date() - sessionHistory[0].timestamp : 0,
            lastActivity: sessionHistory.length > 0 ? 
                sessionHistory[sessionHistory.length - 1].timestamp : null
        };
    }

    // Limpa histórico da conversa
    clearHistory(sessionId = 'default') {
        if (sessionId === 'all') {
            this.conversationHistory.clear();
        } else {
            this.conversationHistory.delete(sessionId);
        }
    }

    // Retorna mensagem de boas-vindas
    getWelcomeMessage() {
        return this.fallbackResponses.greeting[Math.floor(Math.random() * this.fallbackResponses.greeting.length)];
    }

    // Teste de conectividade
    async testConnection() {
        try {
            const testResponse = await this.callGeminiAPI("Teste de conectividade");
            return {
                success: true,
                message: "Conexão com Gemini estabelecida",
                response: testResponse,
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            return {
                success: false,
                message: "Erro na conexão com Gemini",
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }
}

module.exports = { GHZhostAI };
