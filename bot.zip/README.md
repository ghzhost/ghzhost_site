# 🚀 GHZhost IA - API Node.js

API Node.js completa com Express para chatbot da GHZhost usando Google Gemini AI.

## ✨ Funcionalidades

- 🤖 **IA Consultora Luna** - Chatbot inteligente para atendimento ao cliente
- 🔗 **API RESTful** - Endpoints organizados e documentados
- 🎨 **Interface Web Moderna** - Frontend responsivo integrado
- 🔐 **Segurança** - Rate limiting, CORS e validações
- 📊 **Monitoramento** - Logs, estatísticas e health check
- 🔄 **Sessões Múltiplas** - Suporte a múltiplos usuários simultâneos
- 🛡️ **Fallback Inteligente** - Sistema de backup em caso de falha na API

## 🛠️ Tecnologias

- **Node.js** - Runtime JavaScript
- **Express** - Framework web
- **Google Gemini** - IA generativa
- **HTML/CSS/JS** - Frontend moderno
- **dotenv** - Gerenciamento de variáveis de ambiente
- **cors** - Controle de acesso
- **helmet** - Segurança HTTP
- **morgan** - Logs de requisições

## 📦 Instalação

1. **Clone o repositório:**
   ```bash
   git clone <seu-repositorio>
   cd botIA
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Configure as variáveis de ambiente:**
   - Renomeie `.env.example` para `.env`
   - Configure sua chave do Google Gemini:
   ```env
   GEMINI_API_KEY=sua_chave_aqui
   ```

4. **Inicie o servidor:**
   ```bash
   # Desenvolvimento
   npm run dev

   # Produção
   npm start
   ```

## 🔑 Configuração do Google Gemini

1. Acesse [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Crie uma nova API Key
3. Adicione a chave no arquivo `.env`:
   ```env
   GEMINI_API_KEY=AIzaSy...
   ```

## 🌐 Endpoints da API

### Chat
- **POST** `/api/chat` - Enviar mensagem para a IA
- **GET** `/api/welcome` - Obter mensagem de boas-vindas

### Gerenciamento
- **GET** `/api/stats/:sessionId` - Estatísticas da conversa
- **DELETE** `/api/history/:sessionId` - Limpar histórico da sessão

### Utilitários
- **GET** `/api/test` - Testar conectividade com Gemini
- **GET** `/api/info` - Informações da API
- **GET** `/health` - Health check do servidor

## 📄 Exemplo de Uso da API

### Enviar mensagem
```javascript
const response = await fetch('/api/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    message: 'Qual o plano mais barato?',
    sessionId: 'minha-sessao'
  })
});

const data = await response.json();
console.log(data.data.message); // Resposta da Luna
```

### Obter boas-vindas
```javascript
const response = await fetch('/api/welcome');
const data = await response.json();
console.log(data.data.message); // Mensagem de boas-vindas
```

## 🎯 Personalização

### Configurações da Empresa
Edite `src/services/GHZhostAI.js`:
```javascript
this.context = {
  company: "Sua Empresa",
  services: ["seus", "serviços"],
  plans: {
    // seus planos
  }
};
```

### Personalidade da IA
Modifique o `buildSystemPrompt()` para alterar:
- Nome da IA
- Tom de voz
- Conhecimento específico
- Estilo de resposta

### Frontend
Customize `public/index.html`:
- Cores e estilos
- Informações da empresa
- Layout e componentes

## 🔧 Desenvolvimento

### Estrutura do Projeto
```
botIA/
├── src/
│   ├── services/
│   │   └── GHZhostAI.js    # Serviço principal da IA
│   └── routes/
│       └── api.js          # Rotas da API
├── public/
│   └── index.html          # Interface web
├── server.js               # Servidor Express
├── package.json            # Dependências
└── .env                    # Variáveis de ambiente
```

### Scripts Disponíveis
```bash
npm start     # Iniciar servidor
npm run dev   # Desenvolvimento com nodemon
npm test      # Executar testes
```

## 🔒 Segurança

- Rate limiting configurado (100 req/15min)
- CORS habilitado
- Validação de entrada
- Sanitização de dados
- Headers de segurança (Helmet)

## 📊 Monitoramento

- Logs de requisições (Morgan)
- Health check endpoint
- Estatísticas de conversa
- Status da conexão com Gemini

## 🚀 Deploy

### Variáveis de Ambiente Necessárias
```env
PORT=3000
NODE_ENV=production
GEMINI_API_KEY=sua_chave
CORS_ORIGIN=https://seudominio.com
```

### Docker (Opcional)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 🐛 Troubleshooting

### Problema: API Gemini não responde
- Verifique se a `GEMINI_API_KEY` está configurada
- Teste a conectividade com `/api/test`
- Verifique os logs do servidor

### Problema: CORS
- Configure `CORS_ORIGIN` no `.env`
- Verifique se o domínio está correto

### Problema: Rate Limit
- Ajuste `RATE_LIMIT_REQUESTS` no `.env`
- Implemente autenticação para usuários premium

## 📝 Changelog

### v4.0 (Atual)
- ✅ Refatoração completa para Node.js/Express
- ✅ API RESTful organizada
- ✅ Interface web moderna
- ✅ Suporte a múltiplas sessões
- ✅ Sistema de fallback robusto
- ✅ Monitoramento e logs

### v3.0 (Anterior)
- ✅ Integração com Google Gemini
- ✅ Sistema de fallback
- ✅ Análise de intenções

## 📞 Suporte

- **Email**: suporte@ghzhost.com
- **Documentação**: [Link da documentação]
- **Issues**: [Link do repositório]

## 📄 Licença

MIT License - veja [LICENSE](LICENSE) para detalhes.

---

**Desenvolvido com ❤️ pela equipe GHZhost**
