/**
 * Servidor Express para API GHZhost IA com Google Gemini
 * Versão: 4.0 - API Node.js Completa
 * Data: Julho 2025
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const path = require('path');
require('dotenv').config();

const { GHZhostAI } = require('./src/services/GHZhostAI');
const apiRoutes = require('./src/routes/api');

class Server {
    constructor() {
        this.app = express();
        this.port = process.env.PORT || 3000;
        this.ai = new GHZhostAI();
        
        this.setupMiddleware();
        this.setupRoutes();
        this.setupErrorHandling();
    }

    setupMiddleware() {
        // Segurança
        this.app.use(helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
                    fontSrc: ["'self'", "https://fonts.gstatic.com"],
                    scriptSrc: ["'self'", "'unsafe-inline'"],
                    imgSrc: ["'self'", "data:", "https:"],
                    connectSrc: ["'self'", "https://generativelanguage.googleapis.com"]
                }
            }
        }));

        // CORS
        this.app.use(cors({
            origin: process.env.CORS_ORIGIN || '*',
            credentials: true
        }));

        // Rate limiting
        const limiter = rateLimit({
            windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000, // 15 minutos
            max: process.env.RATE_LIMIT_REQUESTS || 100,
            message: {
                error: 'Muitas requisições! Tente novamente em alguns minutos.',
                code: 'RATE_LIMIT_EXCEEDED'
            }
        });
        this.app.use('/api/', limiter);

        // Logging
        this.app.use(morgan('combined'));

        // Body parsing
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

        // Static files
        this.app.use(express.static(path.join(__dirname, 'public')));

        // Disponibilizar instância da IA globalmente
        this.app.use((req, res, next) => {
            req.ai = this.ai;
            next();
        });
    }

    setupRoutes() {
        // Página inicial
        this.app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, 'public', 'index.html'));
        });

        // API Routes
        this.app.use('/api', apiRoutes);

        // Health check
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'OK',
                timestamp: new Date().toISOString(),
                uptime: process.uptime(),
                version: '4.0',
                environment: process.env.NODE_ENV || 'development'
            });
        });

        // 404 Handler
        this.app.use('*', (req, res) => {
            res.status(404).json({
                error: 'Endpoint não encontrado',
                message: 'A rota solicitada não existe',
                available_endpoints: [
                    'GET /',
                    'POST /api/chat',
                    'GET /api/welcome',
                    'GET /api/stats',
                    'DELETE /api/history',
                    'GET /api/test',
                    'GET /health'
                ]
            });
        });
    }

    setupErrorHandling() {
        // Error handler
        this.app.use((err, req, res, next) => {
            console.error('Erro no servidor:', err);
            
            res.status(err.status || 500).json({
                error: 'Erro interno do servidor',
                message: process.env.NODE_ENV === 'development' ? err.message : 'Algo deu errado',
                timestamp: new Date().toISOString()
            });
        });
    }

    async start() {
        try {
            // Testa conexão com Gemini
            console.log('🔍 Testando conexão com Google Gemini...');
            const testResult = await this.ai.testConnection();
            
            if (testResult.success) {
                console.log('✅ Conexão com Gemini estabelecida com sucesso!');
            } else {
                console.log('⚠️  Aviso: Conexão com Gemini falhou, usando fallback');
                console.log('Erro:', testResult.error);
            }

            // Inicia o servidor
            this.app.listen(this.port, () => {
                console.log('🚀 Servidor GHZhost IA iniciado com sucesso!');
                console.log(`📡 Servidor rodando na porta: ${this.port}`);
                console.log(`🌐 Acesse: http://localhost:${this.port}`);
                console.log(`🤖 API disponível em: http://localhost:${this.port}/api`);
                console.log(`💡 Ambiente: ${process.env.NODE_ENV || 'development'}`);
                console.log('═══════════════════════════════════════════════════════');
            });

        } catch (error) {
            console.error('❌ Erro ao iniciar o servidor:', error);
            process.exit(1);
        }
    }
}

// Tratamento de erros não capturados
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    process.exit(1);
});

// Inicializa o servidor
const server = new Server();
server.start();

module.exports = Server;
